package com.csc340.jpacruddemo.user;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    public List<User> getAllUsers() {
        return repo.findAll();
    }

    public User getUser(long id) {
        return repo.getUserById(id);
    }

    public void deleteUser(long id) {
        repo.deleteUserById(id);
    }

    public void saveUser(User user) {
        repo.saveUser(user);
    }

    public void updateUser(User user) {
        repo.updateUser(user);
    }
}

