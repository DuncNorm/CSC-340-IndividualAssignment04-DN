# jpa-crud-demo
## Demo for using Spring JPA and MySQL with MVC
- Clone the project and open it in NetBeans. Do not clean and build yet!
- Open XAMPP Control Panel Dashboard.
- Start Apache.
- Start MySQL.
- Click on MySQL Admin, to open the database dashboard on your browser.
- Create a database with the name 'csc340-f23-crud'.
- Clean and Build the project.
- Run->Set Project Configuration->Customize->Run->Main Class->Browse->Select JpaCrudDemoApplication .java.
- Run the main method.
- On Web Browser:
  * http://localhost:8080/product/all
  * http://localhost:8080/user/all
